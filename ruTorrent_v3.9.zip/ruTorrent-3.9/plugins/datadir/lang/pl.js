﻿/*
 * PLUGIN DATADIR
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.DataDir		= "Przenieś do";
 theUILang.DataDirMove		= "Przenieś dane";
 theUILang.datadirDlgCaption	= "Katalog danych torrenta";
 theUILang.datadirDirNotFound	= "Wtyczka datadir: Nieprawidłowy katalog";
 theUILang.datadirSetDirFail	= "Wtyczka datadir: Operacja nie powiodła się";

thePlugins.get("datadir").langLoaded();