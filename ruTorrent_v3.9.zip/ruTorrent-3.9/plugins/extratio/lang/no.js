﻿/*
 * PLUGIN EXTRATIO
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.ratioRulesManager	= "Regelbehandling";
 theUILang.mnu_ratiorule	= "Ratioregler";
 theUILang.ratAddRule		= "Legg til";
 theUILang.ratDelRule		= "Slett";
 theUILang.ratUpRule		= "Opp";
 theUILang.ratDownRule		= "Ned";
 theUILang.ratioIfLegend	= "Hvis";
 theUILang.ratLabelContain	= "Torrentetikett inneholder";
 theUILang.ratTrackerContain	= "En av torrentens tracker-lenker inneholder";
 theUILang.ratTrackerPublic	= "Alle torrentens trackere er offentlige";
 theUILang.ratTrackerPrivate	= "En av torrentens trackere er privat";
 theUILang.ratioThenLegend	= "Så";
 theUILang.setRatioTo		= "Sett ratio til";
 theUILang.setChannelTo 	= "Sett regulering til";
 theUILang.ratioNewRule 	= "Ny regel";

thePlugins.get("extratio").langLoaded();