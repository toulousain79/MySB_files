﻿/* PLUGIN _CLOUDFLARE
 *
 * Greek language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCfscrape		= "_cloudflare plugin: Το πρόσθετο CfScrape δεν μπορεί να φορτωθεί στην Python";

thePlugins.get("_cloudflare").langLoaded();
