﻿/* PLUGIN _CLOUDFLARE
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCfscrape		= "Плагин _cloudflare: Python не может загрузить модуль CfScrape";

thePlugins.get("_cloudflare").langLoaded();
