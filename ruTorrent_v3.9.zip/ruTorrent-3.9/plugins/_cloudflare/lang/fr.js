﻿/* PLUGIN _CLOUDFLARE
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCfscrape		= "_cloudflare plugin: Le module CfScrape ne peut pas être chargé dans Python";

thePlugins.get("_cloudflare").langLoaded();
