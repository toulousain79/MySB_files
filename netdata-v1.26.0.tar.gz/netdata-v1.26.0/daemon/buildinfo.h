// SPDX-License-Identifier: GPL-3.0-or-later

#ifndef NETDATA_BUILDINFO_H
#define NETDATA_BUILDINFO_H 1

extern void print_build_info(void);

#endif // NETDATA_BUILDINFO_H
