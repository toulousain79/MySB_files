# ruTorrent-MaterialDesign

cd /var/www/rutorrent/plugins/theme/themes

git clone git://github.com/phlooo/ruTorrent-MaterialDesign.git MaterialDesign

chown -R www-data:www-data /var/www/rutorrent/plugins/theme/themes/MaterialDesign

//Screenshot

![material design 1](https://cloud.githubusercontent.com/assets/15751462/14882492/6557d300-0d39-11e6-82fb-5b600ada87a9.png)

![material design 2](https://cloud.githubusercontent.com/assets/15751462/14882542/9f0c4c70-0d39-11e6-81fb-b412a41e6c01.png)
