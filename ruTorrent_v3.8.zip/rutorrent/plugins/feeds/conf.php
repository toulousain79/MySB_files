<?php

$showItemDescription = true;
