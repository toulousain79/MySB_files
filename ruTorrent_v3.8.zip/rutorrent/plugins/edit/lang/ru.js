﻿/*
 * PLUGIN EDIT
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.EditTrackers 		= "Редактировать...";
 theUILang.EditTorrentProperties	= "Настройка торрента";
 theUILang.errorAddTorrent		= "Ошибка добавления торрента";
 theUILang.errorWriteTorrent		= "Ошибка записи файла";
 theUILang.errorReadTorrent		= "Ошибка чтения файла";
 theUILang.cantFindTorrent		= "Исходный торрент файл для данной закачки отсутствует.";

thePlugins.get("edit").langLoaded();