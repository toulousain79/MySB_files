/*
 * PLUGIN THEME
 *
 * English language file.
 *
 * Author: JMSolo - https://plaza.quickbox.io/
 */

 theUILang.themeStandard	= "QuickBox";
 theUILang.theme		= "Theme";

thePlugins.get("theme").langLoaded();
