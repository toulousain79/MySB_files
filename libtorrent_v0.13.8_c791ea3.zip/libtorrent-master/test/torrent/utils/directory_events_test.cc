#include "config.h"

#include <functional>
#include <torrent/exceptions.h>
#include <torrent/utils/directory_events.h>

#include "directory_events_test.h"

CPPUNIT_TEST_SUITE_REGISTRATION(utils_directory_events_test);

void
utils_directory_events_test::setUp() {
}

void
utils_directory_events_test::tearDown() {
}

void
utils_directory_events_test::test_basic() {
}
