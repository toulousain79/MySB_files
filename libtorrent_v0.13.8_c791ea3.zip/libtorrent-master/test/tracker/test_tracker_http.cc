#include "config.h"

#include "test_tracker_http.h"

#include "tracker/tracker_http.h"

CPPUNIT_TEST_SUITE_NAMED_REGISTRATION(test_tracker_http, "tracker");

void
test_tracker_http::test_basic() {
}
