/*
 * PLUGIN MOBILE
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.SortTorrents    = "Sortiere torrents nach";
 theUILang.acs             = "Aufsteigend";
 theUILang.decs            = "Absteigend";

thePlugins.get("mobile").langLoaded();
