/*
 * PLUGIN MOBILE
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.SortTorrents    = "Trier les torrents par";
 theUILang.acs             = "Croissant";
 theUILang.decs            = "Décroissant";

thePlugins.get("mobile").langLoaded();
