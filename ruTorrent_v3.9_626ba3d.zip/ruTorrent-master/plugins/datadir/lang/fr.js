﻿/*
 * PLUGIN DATADIR
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.DataDir		= "Chemin";
 theUILang.DataDirMove		= "Déplacer les fichiers";
 theUILang.datadirDlgCaption	= "Répertoire du torrent";
 theUILang.datadirDirNotFound	= "Plug-in 'DataDir': Répertoire invalide";
 theUILang.datadirSetDirFail	= "Plug-in 'DataDir': L'opération a échoué";

thePlugins.get("datadir").langLoaded();