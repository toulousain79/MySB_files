﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Kopiuj";
 theUILang.Magnet		= "Magnet link";
 theUILang.bulkAdd		= "Dodaj zbiorczo"; 
 theUILang.bulkAddDescription	= "Jeden link na linię (HTTP, magnet lub hash)";

thePlugins.get("bulk_magnet").langLoaded();