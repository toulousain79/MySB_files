﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Копировать";
 theUILang.Magnet		= "Магнет-ссылку";
 theUILang.bulkAdd		= "Загрузить торренты"; 
 theUILang.bulkAddDescription	= "Одна ссылка на строку (HTTP, магнет-ссылки или хеш-суммы)";

thePlugins.get("bulk_magnet").langLoaded();