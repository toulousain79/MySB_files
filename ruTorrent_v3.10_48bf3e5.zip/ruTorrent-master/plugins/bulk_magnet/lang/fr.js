﻿/*
 * PLUGIN BULK_MAGNET
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Copier";
 theUILang.Magnet		= "Lien magnet";
 theUILang.bulkAdd		= "Importer des torrents par lot";
 theUILang.bulkAddDescription	= "Un lien par ligne ( HTTP, magnet ou hash )";

thePlugins.get("bulk_magnet").langLoaded();
