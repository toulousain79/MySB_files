﻿/*
 * PLUGIN CHUNKS
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Trozos";
 theUILang.cAvail		= "Disponibilidad";
 theUILang.cDownloaded		= "Descargados";
 theUILang.cMode		= "Modo";
 theUILang.chunksCount		= "Cuenta de trozos";
 theUILang.chunkSize		= "Tamaño de trozos";
 theUILang.cLegend		= "Leyenda";
 theUILang.cLegendVal		= [ "4 trozos por celda", "1 trozo por celda" ];

thePlugins.get("chunks").langLoaded();