<?php

$destPathForLink 	= "/srv/ready/";	// Destination directory. Absolute path with trail slash.

?>
