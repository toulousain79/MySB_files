for_rsync
=========

The plugin is intended to add an option to the right-click menu of rutorrent to create a symlink to the downloaded torrent data in another directory.

INSTALL: Just clone this repo into your rutorrent/plugins directory, edit the conf file with
the location your want the symlinks to be created in and reload rutorrent :)

Note that this was NOT made by me but by Novik.

More here: http://scriptthe.net/2013/07/25/mark-for-rsync-symlink-creating-rutorrent-plugin/
