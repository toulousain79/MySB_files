[![Donate](https://rakshasa.github.io/rtorrent/donate_paypal_green.svg)](https://paypal.me/jarisundell)

RTorrent BitTorrent Client
========

Introduction
------------

To learn how to use rTorrent visit the [Wiki](https://github.com/rakshasa/rtorrent/wiki).

Stable
------

 * [http://rtorrent.net/downloads/libtorrent-0.13.6.tar.gz](http://rtorrent.net/downloads/libtorrent-0.13.6.tar.gz)
 * [http://rtorrent.net/downloads/rtorrent-0.9.6.tar.gz](http://rtorrent.net/downloads/rtorrent-0.9.6.tar.gz)

Latest
------

 * [http://rtorrent.net/downloads/libtorrent-0.13.8.tar.gz](http://rtorrent.net/downloads/libtorrent-0.13.8.tar.gz)
 * [http://rtorrent.net/downloads/rtorrent-0.9.8.tar.gz](http://rtorrent.net/downloads/rtorrent-0.9.8.tar.gz)

Donate to rTorrent development
------------------------------

 * [Paypal](https://paypal.me/jarisundell)
 * [Patreon](https://www.patreon.com/rtorrent)
 * [SubscribeStar](https://www.subscribestar.com/rtorrent)
 * BitCoin: 1MpmXm5AHtdBoDaLZstJw8nupJJaeKu8V8
 * Etherium: 0x9AB1e3C3d8a875e870f161b3e9287Db0E6DAfF78
 * LiteCoin: LdyaVR67LBnTf6mAT4QJnjSG2Zk67qxmfQ

Help keep rTorrent development going by donating to its creator.
