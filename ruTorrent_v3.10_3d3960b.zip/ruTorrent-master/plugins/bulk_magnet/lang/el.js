﻿/*
 * PLUGIN BULK_MAGNET
 *
 * Greek language file.
 *
 * Author: 
 */

 theUILang.bulkCopy		= "Αντιγραφή";
 theUILang.Magnet		= "Σύνδεσμος Magnet";
 theUILang.bulkAdd		= "Μαζική φόρτωση"; 
 theUILang.bulkAddDescription	= "Ένας σύνδεσμος ανά γραμμή (HTTP, σύνδεσμος magnet ή hash)";

thePlugins.get("bulk_magnet").langLoaded();
