﻿/*
 * PLUGIN CHUNKS
 *
 * Italian language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Frammenti";
 theUILang.cAvail		= "Disponibilità";
 theUILang.cDownloaded		= "Scaricati";
 theUILang.cMode		= "Modalità";
 theUILang.chunksCount		= "Conteggio frammenti";
 theUILang.chunkSize		= "Dimensione frammento";
 theUILang.cLegend		= "Legenda";
 theUILang.cLegendVal		= [ "4 frammenti per cella", "1 frammento per cella" ];

thePlugins.get("chunks").langLoaded();
