﻿/*
 * PLUGIN DATA
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.getData		= "Ottieni File";
 theUILang.cantAccessData	= "L'utente che esegue il webserver non può accedere ai dati di questo torrent.";

thePlugins.get("data").langLoaded();
