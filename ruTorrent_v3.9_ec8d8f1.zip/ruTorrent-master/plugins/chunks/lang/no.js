﻿/*
 * PLUGIN CHUNKS
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.Chunks		= "Deler";
 theUILang.cAvail		= "Tilgjengelighet";
 theUILang.cDownloaded		= "Nedlastet";
 theUILang.cMode		= "Modus";
 theUILang.chunksCount		= "Antall deler";
 theUILang.chunkSize		= "Delstørrelse";
 theUILang.cLegend		= "Legende";
 theUILang.cLegendVal		= [ "4 deler per celle", "1 del per celle" ];

thePlugins.get("chunks").langLoaded();