<?php
// ----------------------------------
//  __/\\\\____________/\\\\___________________/\\\\\\\\\\\____/\\\\\\\\\\\\\___
//   _\/\\\\\\________/\\\\\\_________________/\\\/////////\\\_\/\\\/////////\\\_
//    _\/\\\//\\\____/\\\//\\\____/\\\__/\\\__\//\\\______\///__\/\\\_______\/\\\_
//     _\/\\\\///\\\/\\\/_\/\\\___\//\\\/\\\____\////\\\_________\/\\\\\\\\\\\\\\__
//      _\/\\\__\///\\\/___\/\\\____\//\\\\\________\////\\\______\/\\\/////////\\\_
//       _\/\\\____\///_____\/\\\_____\//\\\____________\////\\\___\/\\\_______\/\\\_
//        _\/\\\_____________\/\\\__/\\_/\\\______/\\\______\//\\\__\/\\\_______\/\\\_
//         _\/\\\_____________\/\\\_\//\\\\/______\///\\\\\\\\\\\/___\/\\\\\\\\\\\\\/__
//          _\///______________\///___\////__________\///////////_____\/////////////_____
//			By toulousain79 ---> https://github.com/toulousain79/
//
//#####################################################################
//
//	Copyright (c) 2013 toulousain79 (https://github.com/toulousain79/)
//	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//	--> Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
//
//#################### FIRST LINE #####################################

// Infos stats
define('STATS_VERSION', '0.4');
define('WEB_ROOT', dirname(__FILE__));
define("USER_AGENT", "MySB"); // User-Agent allowed
define('WEB_INC', WEB_ROOT . '/inc');
define('Stats_DB', WEB_ROOT. '/db/Stats.sq3');
define('FILE_MEDOO', WEB_INC. '/medoo.min.php');

// VARs
$HttpUserAgent = $_SERVER['HTTP_USER_AGENT']; // User-Agent Ident
$RequestIp = $_SERVER['REMOTE_ADDR']; // Request IP
$Date = date("Y-m-d");
$Hour = date("H:i:s");
$Box = gethostbyname('xxx.xxxxx.xxx');

// Databases
require_once(FILE_MEDOO);
use Medoo\Medoo;
$Stats_DB = new medoo([
	'database_type' => 'sqlite',
	'database_file' => Stats_DB,
	'database_name' => 'Stats'
]);

// Start
date_default_timezone_set('Europe/Paris');
$Today = new DateTime();
$Tempo = new DateInterval('P30D'); // P15D for 15 days, P30D for 30 days

if ( $HttpUserAgent == USER_AGENT ) {
	$version = $_POST["version"];
	$country = $_POST["country"];
	$machine_id = $_POST["machine_id"];
	if ( ($country == 'unknown') || ($country == '') ) {
		$country = geoip_country_name_by_name($RequestIp);
		if ( $country == '' ) { $country = 'unknown'; }
	}

	if ( ($version != '') && ($machine_id != '') ) {
		$datas = $Stats_DB->get("stats", ["current_version"], ["machine_id" => "$machine_id"]);
		$current_version = $datas["current_version"];

		if ( ($current_version != '') && ($current_version != $version) ) {
			// Update it!
			$result = $Stats_DB->update("stats", ["current_version" => "$version", "previous_version" => "$current_version", "date" => "$Date $Hour", "country" => "$country"], ["machine_id" => "$machine_id"]);
		} else {
			// Add it!
			$result = $Stats_DB->insert("stats", ["current_version" => "$version", "machine_id" => "$machine_id", "date" => "$Date $Hour", "country" => "$country"]);
		}

		$return = $result->rowCount();
		if( $return != 0 ) {
			echo "Statistics updated at $Date $Hour in $country for machine_id $machine_id !";
		}
	}

	$AllStats = $Stats_DB->select("stats", ["date", "machine_id"], ["ORDER" => "date ASC"]);
	foreach($AllStats as $Stats) {
		$LastUpdate  = new DateTime($Stats["date"]);
		if ($LastUpdate->add($Tempo) < $Today) {
			$Stats_DB->delete("stats", ["machine_id" => $Stats["machine_id"]]);
		}
	}

} else {
	$CountInstall = $Stats_DB->count("stats", "stats_id");
	$AllStats = $Stats_DB->select("stats", ["current_version", "previous_version", "date", "country", "machine_id"], ["ORDER" => "date ASC"]);
?>
<html>
<head>
	<title>MySB - Statistics</title>
	<meta name="robots" content="noindex, nofollow" />
	<link rel="shortcut icon" href="/statistics/favicon.ico" />
</head>
<body>
	<div align="center">
		<table style="border-spacing:1;">
			<tr>
				<th>Total install</th>
			</tr>
			<tr style="text-align:center;">
				<td><?php echo $CountInstall; ?></td>
			</tr>
		</table>
	</div>

	<div align="center">
		<table border="1">
			<tr>
				<th>Current<br />Version</th>
				<th>Previous<br />Version</th>
<?php
					if ( $RequestIp == $Box ) {
						echo '<th>Country</th>';
						echo '<th>Machine ID</th>';
					}
?>
				<th>Date</th>
			</tr>
<?php
	foreach($AllStats as $Stats) {
?>
			<tr style="text-align:center;">
				<td ><?php echo $Stats["current_version"]; ?></td>
				<td ><?php echo $Stats["previous_version"]; ?></td>
<?php
					if ( $RequestIp == $Box ) {
						echo '<td>' . $Stats["country"] . '</td>';
						echo '<td>' . $Stats["machine_id"] . '</td>';
					}
?>
				<td><?php echo $Stats["date"]; ?></td>
			</tr>
<?php
	}
?>
		</table>
	</div>
</body>
<?php
}

//#################### LAST LINE ######################################
